<template>
<div class="col-lg-3 col-md-4 col-xs-6 thumb">
      <div class="panel panel-default">
          <div class="panel-body">
                  <h5>Site Name : 91 Porn</h5>
                  <h5>URL : www.91porn.com</h5>
                  <h5>Type : homemade</h5>
                  <hr>
                  <a href="http://www.91porn.com" class="btn btn-info btn-block" role="button">More Servers Detail</a>
          </div>
      </div>
</div>
</template>

<script>


export default {
    data: {

    },
    components: {

    },
    replace: false
}

</script>

<style>
.panel-default{
  border-radius: 25px;
}
</style>
